<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_Hassan_Momen_traveler
 */

get_header();
?>
	<div class="jumbotron">
		<center><h1 class="text">MOUNT EVEREST</h1>
		<h3 class="text1">- HANDMADE APPAREL -</h3></center>
	</div>
	<section class="boxes">
	<div class="container mt-5">
        <div class="row">
            <div class="col-lg-4 col-sm-12 pb-5">
                <div class="box wow bounceInUp">
                       <i class="fa fa-snowflake-o" aria-hidden="true"></i>
                        <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
            <div class="col-lg-4 col-sm-12 pb-5">
                <div class="box wow bounceInUp">
                        <i class="fa fa-gears" aria-hidden="true"></i>
                        <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
            <div class="col-lg-4 col-sm-12 pb-5">
                <div class="box wow bounceInUp">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
        </div>
    </div>
    </section>
    <hr>


<?php
 get_sidebar();
get_footer();
?>
