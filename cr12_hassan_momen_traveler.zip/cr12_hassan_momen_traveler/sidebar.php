<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_Hassan_Momen_traveler
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area">
	<div class= "container ">
    <div class= "row">
    	<div class="col-lg-6 col-xs-12 mb-5">
    	<?php dynamic_sidebar( 'sidebar-1' ); ?>
    	</div>
    	<div class="col-lg-6 col-xs-12 mb-5 pb-5">
           <?php if (have_posts()) : ?>
                    <?php 
                  
                     while ( have_posts() ) : the_post(); ?>
                    <div class= "card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <div class="post-header">
                        <div class="date text-center"><?php the_time( 'M j y' ); ?></div>
                        <center><h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                        <div class="author"><?php the_author(); ?></div></center>
                        </div><!--end post header-->
                        
                        <center><?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
                        <?php the_content(); ?>
                        <?php edit_post_link(); ?>
                        <?php wp_link_pages(); ?> </center>
                        <!--end entry-->
                        <div class="post-footer text-center">
                        <div class="comments"><?php comments_popup_link( 'Leave a Comment', '1 Comment', '% Comments' ); ?></div>
                        </div><!--end post footer-->
                        </div><!--end post-->
                    <?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
                        <div class="navigation index">
                        <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
                        <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
                        </div><!--end navigation-->
                    <?php else : ?>
                    <?php endif; ?>
                    </div>
</aside><!-- #secondary -->